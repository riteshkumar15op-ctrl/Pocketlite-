package net.caffeinemc.mods.sodium.client.render.chunk.tree;

public abstract class BaseForest<T extends Tree> implements Forest<T> {
    protected final int baseOffsetX, baseOffsetY, baseOffsetZ;
    final float buildDistance;

    protected BaseForest(int baseOffsetX, int baseOffsetY, int baseOffsetZ, float buildDistance) {
        this.baseOffsetX = baseOffsetX;
        this.baseOffsetY = baseOffsetY;
        this.baseOffsetZ = baseOffsetZ;
        this.buildDistance = buildDistance;
    }

    protected abstract T makeTree(int offsetX, int offsetY, int offsetZ);
}
