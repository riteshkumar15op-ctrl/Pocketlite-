package net.caffeinemc.mods.sodium.client.config.builder;

import net.caffeinemc.mods.sodium.api.config.ConfigState;
import net.caffeinemc.mods.sodium.api.config.StorageEventHandler;
import net.caffeinemc.mods.sodium.api.config.option.OptionBinding;
import net.caffeinemc.mods.sodium.api.config.option.OptionFlag;
import net.caffeinemc.mods.sodium.api.config.option.OptionImpact;
import net.caffeinemc.mods.sodium.api.config.structure.BooleanOptionBuilder;
import net.caffeinemc.mods.sodium.client.config.structure.BooleanOption;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

class BooleanOptionBuilderImpl extends StatefulOptionBuilderImpl<BooleanOption, Boolean> implements BooleanOptionBuilder {
    BooleanOptionBuilderImpl(Identifier id) {
        super(id);
    }

    @Override
    BooleanOption build() {
        this.prepareBuild();

        return new BooleanOption(
                this.id,
                this.getDependencies(),
                this.getName(),
                this.getEnabled(),
                this.getStorage(),
                this.getTooltipProvider(),
                this.getImpact(),
                this.getFlags(),
                this.getDefaultValue(),
                this.getControlHiddenWhenDisabled(),
                this.getBinding(),
                this.getApplyHook());
    }

    @Override
    Class<BooleanOption> getOptionClass() {
        return BooleanOption.class;
    }

    @Override
    public BooleanOptionBuilder setName(Component name) {
        super.setName(name);
        return this;
    }

    @Override
    public BooleanOptionBuilder setStorageHandler(StorageEventHandler storage) {
        super.setStorageHandler(storage);
        return this;
    }

    @Override
    public BooleanOptionBuilder setTooltip(Component tooltip) {
        super.setTooltip(tooltip);
        return this;
    }

    @Override
    public BooleanOptionBuilder setTooltip(Function<Boolean, Component> tooltip) {
        super.setTooltip(tooltip);
        return this;
    }

    @Override
    public BooleanOptionBuilder setImpact(OptionImpact impact) {
        super.setImpact(impact);
        return this;
    }

    @Override
    public BooleanOptionBuilder setFlags(OptionFlag... flags) {
        super.setFlags(flags);
        return this;
    }

    @Override
    public BooleanOptionBuilder setFlags(Identifier... flags) {
        super.setFlags(flags);
        return this;
    }

    @Override
    public BooleanOptionBuilder setDefaultValue(Boolean value) {
        super.setDefaultValue(value);
        return this;
    }

    @Override
    public BooleanOptionBuilder setDefaultProvider(Function<ConfigState, Boolean> provider, Identifier... dependencies) {
        super.setDefaultProvider(provider, dependencies);
        return this;
    }

    @Override
    public BooleanOptionBuilder setEnabled(boolean available) {
        super.setEnabled(available);
        return this;
    }

    @Override
    public BooleanOptionBuilder setEnabledProvider(Function<ConfigState, Boolean> provider, Identifier... dependencies) {
        super.setEnabledProvider(provider, dependencies);
        return this;
    }

    @Override
    public BooleanOptionBuilder setControlHiddenWhenDisabled(boolean hidden) {
        super.setControlHiddenWhenDisabled(hidden);
        return this;
    }

    @Override
    public BooleanOptionBuilder setBinding(Consumer<Boolean> save, Supplier<Boolean> load) {
        super.setBinding(save, load);
        return this;
    }

    @Override
    public BooleanOptionBuilder setBinding(OptionBinding<Boolean> binding) {
        super.setBinding(binding);
        return this;
    }

    @Override
    public BooleanOptionBuilder setApplyHook(Consumer<ConfigState> hook) {
        super.setApplyHook(hook);
        return this;
    }
}
