package net.caffeinemc.mods.sodium.client.gui.options.control;

import com.mojang.blaze3d.platform.Monitor;
import net.caffeinemc.mods.sodium.api.config.option.ControlValueFormatter;
import net.caffeinemc.mods.sodium.client.compatibility.environment.OsUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.function.IntFunction;

public class ControlValueFormatterImpls {
    private ControlValueFormatterImpls() {
    }

    public static ControlValueFormatter guiScale() {
        return (v) -> (v == 0) ? Component.translatable("options.guiScale.auto") : Component.literal(v + "x");
    }

    public static ControlValueFormatter resolution() {
        return (v) -> {
            Monitor monitor = Minecraft.getInstance().getWindow().findBestMonitor();

            var os = OsUtils.getOs();
            if (monitor == null || !(os == OsUtils.OperatingSystem.WIN || os == OsUtils.OperatingSystem.MAC)) {
                return Component.empty();
            } else if (0 == v) {
                return Component.translatable("options.fullscreen.current");
            } else {
                return Component.literal(monitor.mode(Math.min(v - 1, monitor.modeCount() - 1)).toString().replace(" (24bit)", ""));
            }
        };
    }

    public static ControlValueFormatter fpsLimit() {
        return (v) -> (v == 260) ? Component.translatable("options.framerateLimit.max") : Component.translatable("options.framerate", v);
    }

    public static ControlValueFormatter brightness() {
        return (v) -> {
            if (v == 0) {
                return Component.translatable("options.gamma.min");
            } else if (v == 50) {
                return Component.translatable("options.gamma.default");
            } else if (v == 100) {
                return Component.translatable("options.gamma.max");
            } else {
                return Component.literal(v + "%");
            }
        };
    }

    public static ControlValueFormatter biomeBlend() {
        return (v) -> {
            if (v < 0 || v > 7) {
                return Component.translatable("parsing.int.invalid", v);
            } else if (v == 0) {
                return Component.translatable("gui.none");
            } else {
                int sv = 2 * v + 1;
                return Component.translatable("sodium.options.biome_blend.value", sv, sv);
            }
        };
    }

    public static ControlValueFormatter translateVariable(String key) {
        return (v) -> Component.translatable(key, v);
    }

    public static ControlValueFormatter percentage() {
        return (v) -> Component.literal(v + "%");
    }

    public static ControlValueFormatter multiplier() {
        return (v) -> Component.literal(v + "x");
    }

    public static ControlValueFormatter quantityOrDisabled(IntFunction<Component> valueText, Component disableText) {
        return (v) -> v == 0 ? disableText : valueText.apply(v);
    }

    public static ControlValueFormatter number() {
        return (v) -> Component.literal(String.valueOf(v));
    }

    public static ControlValueFormatter anisotropyBit() {
        return (v -> {
            if (v == 0) {
                return Component.translatable("options.off");
            } else {
                return Component.literal((1 << v) + "x");
            }
        });
    }

    public static ControlValueFormatter chunkFade() {
        return (v -> {
            if (v == 0) {
                return Component.translatable("gui.none");
            } else {
                return Component.translatable("sodium.options.chunk_fade_time.value", (double) v / 1000.0);
            }
        });
    }
}
