package net.caffeinemc.mods.sodium.client.config.builder;

import net.caffeinemc.mods.sodium.api.config.ConfigState;
import net.caffeinemc.mods.sodium.api.config.structure.ExternalButtonOptionBuilder;
import net.caffeinemc.mods.sodium.client.config.structure.ExternalButtonOption;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.apache.commons.lang3.Validate;

import java.util.function.Consumer;
import java.util.function.Function;

class ExternalButtonOptionBuilderImpl extends StaticOptionBuilderImpl<ExternalButtonOption> implements ExternalButtonOptionBuilder {
    private Consumer<Screen> currentScreenConsumer;

    ExternalButtonOptionBuilderImpl(Identifier id) {
        super(id);
    }

    @Override
    void validateData() {
        super.validateData();

        Validate.notNull(this.getCurrentScreenConsumer(), "Screen provider must be set");
    }

    @Override
    ExternalButtonOption build() {
        this.prepareBuild();

        return new ExternalButtonOption(this.id, this.getDependencies(), this.getName(), this.getEnabled(), this.getTooltip(), this.getCurrentScreenConsumer());
    }

    @Override
    Class<ExternalButtonOption> getOptionClass() {
        return ExternalButtonOption.class;
    }

    Consumer<Screen> getCurrentScreenConsumer() {
        return this.getFirstNotNull(this.currentScreenConsumer, ExternalButtonOption::getCurrentScreenConsumer);
    }

    @Override
    public ExternalButtonOptionBuilder setName(Component name) {
        super.setName(name);
        return this;
    }

    @Override
    public ExternalButtonOptionBuilder setEnabled(boolean available) {
        super.setEnabled(available);
        return this;
    }

    @Override
    public ExternalButtonOptionBuilder setEnabledProvider(Function<ConfigState, Boolean> provider, Identifier... dependencies) {
        super.setEnabledProvider(provider, dependencies);
        return this;
    }

    @Override
    public ExternalButtonOptionBuilder setTooltip(Component tooltip) {
        super.setTooltip(tooltip);
        return this;
    }

    @Override
    public ExternalButtonOptionBuilder setScreenConsumer(Consumer<Screen> currentScreenConsumer) {
        this.currentScreenConsumer = currentScreenConsumer;
        return this;
    }
}
