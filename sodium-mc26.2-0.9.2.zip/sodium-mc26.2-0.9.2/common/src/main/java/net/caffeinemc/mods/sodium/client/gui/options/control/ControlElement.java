package net.caffeinemc.mods.sodium.client.gui.options.control;

import net.caffeinemc.mods.sodium.client.config.structure.Option;
import net.caffeinemc.mods.sodium.client.gui.ColorTheme;
import net.caffeinemc.mods.sodium.client.gui.Colors;
import net.caffeinemc.mods.sodium.client.gui.Layout;
import net.caffeinemc.mods.sodium.client.gui.widgets.AbstractWidget;
import net.caffeinemc.mods.sodium.client.util.Dim2i;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.ComponentPath;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.navigation.FocusNavigationEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import org.jspecify.annotations.Nullable;

public abstract class ControlElement extends AbstractWidget {
    protected final AbstractOptionList list;
    protected final ColorTheme theme;

    public ControlElement(AbstractOptionList list, Dim2i dim, ColorTheme theme) {
        super(dim);
        this.list = list;
        this.theme = theme;
    }

    public abstract Option getOption();

    public int getContentWidth() {
        return this.getOption().getControl().getMaxWidth();
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        String name = this.getOption().getName().getString();

        // add the star suffix before truncation to prevent it from overlapping with the label text
        if (this.getOption().isEnabled() && this.getOption().hasChanged()) {
            name = name + " *";
        }

        name = this.truncateLabelToFit(name);

        String label;
        if (this.getOption().isEnabled()) {
            if (this.getOption().hasChanged()) {
                label = ChatFormatting.ITALIC + name;
            } else {
                label = ChatFormatting.WHITE + name;
            }
        } else {
            label = String.valueOf(ChatFormatting.GRAY) + ChatFormatting.STRIKETHROUGH + name;
        }

        this.hovered = this.isMouseOver(mouseX, mouseY);

        this.drawRect(graphics, this.getX(), this.getY(), this.getLimitX(), this.getLimitY(), this.hovered ? Colors.BACKGROUND_HOVER : Colors.BACKGROUND_LIGHT);
        this.drawString(graphics, label, this.getX() + Layout.OPTION_TEXT_SIDE_PADDING, this.getCenterY() + Layout.REGULAR_TEXT_BASELINE_OFFSET, Colors.FOREGROUND);

        if (this.isFocused()) {
            this.drawBorder(graphics, this.getX(), this.getY(), this.getLimitX(), this.getLimitY(), -1);
        }
    }

    protected MutableComponent formatDisabledControlValue(Component value) {
        return value.copy().withStyle(Style.EMPTY
                .withColor(ChatFormatting.GRAY)
                .withItalic(true));
    }

    protected String truncateLabelToFit(String name) {
        return this.truncateTextToFit(name, this.getWidth() - this.getContentWidth() - Layout.OPTION_LABEL_END_PADDING);
    }

    @Override
    public int getY() {
        return super.getY() - this.list.getScrollAmount();
    }

    @Override
    public @Nullable ComponentPath nextFocusPath(FocusNavigationEvent event) {
        if (!this.getOption().isEnabled()) {
            return null;
        }
        return super.nextFocusPath(event);
    }
}
