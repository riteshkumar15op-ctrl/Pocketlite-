package net.caffeinemc.mods.sodium.client.render.chunk;

import it.unimi.dsi.fastutil.objects.*;
import net.caffeinemc.mods.sodium.api.texture.SpriteUtil;
import net.caffeinemc.mods.sodium.client.SodiumClientMod;
import net.caffeinemc.mods.sodium.client.render.chunk.async.CullTask;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.BuilderTaskOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.ChunkBuildOutput;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.estimation.*;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.executor.ChunkBuilder;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.executor.ChunkJobCollector;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.executor.ChunkJobResult;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.tasks.ChunkBuilderMeshingTask;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.tasks.ChunkBuilderSortingTask;
import net.caffeinemc.mods.sodium.client.render.chunk.compile.tasks.ChunkBuilderTask;
import net.caffeinemc.mods.sodium.client.render.chunk.data.BuiltSectionInfo;
import net.caffeinemc.mods.sodium.client.render.chunk.lists.*;
import net.caffeinemc.mods.sodium.client.render.chunk.occlusion.*;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegion;
import net.caffeinemc.mods.sodium.client.render.chunk.region.RenderRegionManager;
import net.caffeinemc.mods.sodium.client.render.chunk.storage.QueuedSectionStorage;
import net.caffeinemc.mods.sodium.client.render.chunk.storage.SectionStorage;
import net.caffeinemc.mods.sodium.client.render.chunk.translucent_sorting.SortBehavior;
import net.caffeinemc.mods.sodium.client.render.chunk.translucent_sorting.SortBehavior.PriorityMode;
import net.caffeinemc.mods.sodium.client.render.chunk.translucent_sorting.data.*;
import net.caffeinemc.mods.sodium.client.render.chunk.translucent_sorting.trigger.CameraMovement;
import net.caffeinemc.mods.sodium.client.render.chunk.translucent_sorting.trigger.SortTriggering;
import net.caffeinemc.mods.sodium.client.render.chunk.tree.RemovableMultiForest;
import net.caffeinemc.mods.sodium.client.render.chunk.vertex.format.ChunkMeshFormats;
import net.caffeinemc.mods.sodium.client.render.util.RenderAsserts;
import net.caffeinemc.mods.sodium.client.render.viewport.Viewport;
import net.caffeinemc.mods.sodium.client.services.PlatformRuntimeInformation;
import net.caffeinemc.mods.sodium.client.util.FogParameters;
import net.caffeinemc.mods.sodium.client.util.MathUtil;
import net.caffeinemc.mods.sodium.client.world.LevelSlice;
import net.caffeinemc.mods.sodium.client.world.cloned.ChunkRenderContext;
import net.caffeinemc.mods.sodium.client.world.cloned.ClonedChunkSectionCache;
import net.minecraft.client.Camera;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.SectionPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunkSection;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector3dc;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class RenderSectionManager {
    private static final float NEARBY_REBUILD_DISTANCE = Mth.square(16.0f);
    private static final float IMMEDIATE_PRESENT_DISTANCE = Mth.square(64.0f);
    private static final float NEARBY_SORT_DISTANCE = Mth.square(25.0f);

    private static final float FRAME_DURATION_UPLOAD_FRACTION = 0.3f;
    private static final long MIN_UPLOAD_DURATION_BUDGET = 10_000_000L; // 2ms

    private final ChunkBuilder builder;

    public final RenderRegionManager regions;
    private final ClonedChunkSectionCache sectionCache;

    private final SectionStorage renderSections = new QueuedSectionStorage();

    private final ConcurrentLinkedDeque<ChunkJobResult<? extends BuilderTaskOutput>> buildResults = new ConcurrentLinkedDeque<>();
    private final JobDurationEstimator jobDurationEstimator = new JobDurationEstimator();
    private final MeshTaskSizeEstimator meshTaskSizeEstimator;
    private final UploadDurationEstimator jobUploadDurationEstimator = new UploadDurationEstimator();
    private ChunkJobCollector lastBlockingCollector;
    private int thisFrameBlockingTasks;
    private int nextFrameBlockingTasks;
    private int deferredTasks;

    private final ChunkRenderer chunkRenderer;

    private final ClientLevel level;

    private final ReferenceSet<RenderSection> sectionsWithGlobalEntities = new ReferenceOpenHashSet<>();

    private final OcclusionCuller occlusionCuller;

    private final int renderDistance;
    private final SortBehavior sortBehavior;

    private final SortTriggering sortTriggering;

    @NonNull
    private SortedRenderLists renderLists;

    private DeferredTaskList taskLists;
    private final EnumMap<DeferMode, ReferenceLinkedOpenHashSet<RenderSection>> importantTasks;

    private int frame;
    private long lastFrameDuration = -1;
    private long averageFrameDuration = -1;
    private long lastFrameAtTime = System.nanoTime();
    private static final float FRAME_DURATION_UPDATE_RATIO = 0.05f;

    private boolean needsGraphUpdate = true;
    private boolean needsRenderListUpdate = true;
    private boolean cameraChanged = false;
    private int cameraStableSince = -1;

    private @Nullable Vector3dc cameraPosition;

    private final ExecutorService asyncCullExecutor = Executors.newSingleThreadExecutor(RenderSectionManager::makeAsyncCullThread);
    private CullTask pendingTask = null;
    private long averageCullDurationNanos = -1;
    private static final float CULL_DURATION_UPDATE_RATIO = 0.2f;

    private SectionTree renderTree = null;
    private final Map<CullType, SectionTree> cullResults = new EnumMap<>(CullType.class);
    private final RemovableMultiForest renderableSectionTree;

    private final AsyncCameraTimingControl cameraTimingControl = new AsyncCameraTimingControl();

    public RenderSectionManager(ClientLevel level, int renderDistance, SortBehavior sortBehavior) {
        this.meshTaskSizeEstimator = new MeshTaskSizeEstimator(level);

        this.chunkRenderer = new DefaultChunkRenderer(ChunkMeshFormats.getCurrent());

        this.level = level;
        this.builder = new ChunkBuilder(level, ChunkMeshFormats.getCurrent());

        this.renderDistance = renderDistance;
        this.sortBehavior = sortBehavior;

        if (this.sortBehavior != SortBehavior.OFF) {
            this.sortTriggering = new SortTriggering();
        } else {
            this.sortTriggering = null;
        }

        this.regions = new RenderRegionManager();
        this.sectionCache = new ClonedChunkSectionCache(this.level);

        this.renderLists = SortedRenderLists.empty();
        this.occlusionCuller = new OcclusionCuller(this.renderSections, this.level);

        this.renderableSectionTree = new RemovableMultiForest(renderDistance);

        this.importantTasks = new EnumMap<>(DeferMode.class);
        for (var deferMode : DeferMode.values()) {
            this.importantTasks.put(deferMode, new ReferenceLinkedOpenHashSet<>());
        }
    }

    public void prepareFrame(Vector3dc cameraPosition) {
        this.cameraPosition = cameraPosition;

        var now = System.nanoTime();
        this.lastFrameDuration = now - this.lastFrameAtTime;
        this.lastFrameAtTime = now;
        if (this.averageFrameDuration == -1) {
            this.averageFrameDuration = this.lastFrameDuration;
        } else {
            this.averageFrameDuration = MathUtil.exponentialMovingAverage(this.averageFrameDuration, this.lastFrameDuration, FRAME_DURATION_UPDATE_RATIO);
        }
        this.averageFrameDuration = Mth.clamp(this.averageFrameDuration, 1_000_100, 100_000_000);
    }

    public void prepareRender() {
        this.frame += 1;
        if (this.cameraChanged) {
            this.invalidateRenderLists();
        }
        this.chunkRenderer.rotate();
    }

    public void prepareRenderTrees(Viewport viewport, FogParameters fogParameters, boolean useOcclusionCulling) {
        // cancel task if not in progress
        if (this.pendingTask != null && this.pendingTask.cancelIfNotStarted()) {
            this.pendingTask = null;

            // end the safe read phase on task cancellation
            this.renderSections.endSafeReadPhase();
        }

        // consume the results of completed tasks
        this.consumeCullTaskResults(false);

        // discard unusable present and pending frustum-tested trees
        if (this.cameraChanged) {
            this.cullResults.remove(CullType.LOCAL);
        }

        // if the origin exists in the graph, schedule new async culling task
        if (!this.isOutOfGraph(viewport.getChunkCoord()) && (this.cameraChanged || this.needsGraphUpdate)) {
            this.scheduleAsyncWork(viewport, fogParameters, useOcclusionCulling);
        }
    }

    public void finalizeRenderLists(Camera camera, Viewport viewport, FogParameters fogParameters, boolean updateChunksImmediately) {
        var syncRender = this.cameraTimingControl.getShouldRenderSync(camera);
        if (updateChunksImmediately || syncRender && (this.needsGraphUpdate || this.needsRenderListUpdate)) {
            this.renderOutOfGraph(viewport, fogParameters);
        } else if (this.needsRenderListUpdate) {
            this.readRenderListFromTree(viewport, fogParameters);
        }

        this.needsRenderListUpdate = false;
        this.cameraChanged = false;
    }

    private void consumeCullTaskResults(boolean waitForCompletion) {
        if (this.pendingTask == null) {
            return;
        }

        // if there's a waiting viewport, don't skip unfinished task
        if (!waitForCompletion && !this.pendingTask.isDone()) {
            return;
        }

        var result = this.pendingTask.getResult();

        var elapsedNanos = this.pendingTask.getElapsedNanos();
        if (this.averageCullDurationNanos == -1) {
            this.averageCullDurationNanos = elapsedNanos;
        } else {
            this.averageCullDurationNanos = MathUtil.exponentialMovingAverage(this.averageCullDurationNanos, elapsedNanos, CULL_DURATION_UPDATE_RATIO);
        }

        // reject local tree result if camera has changed since we submitted this task, as it would be constructed using different camera parameters (such as the frustum) and thus have false positive culls when interpreted with the current camera parameters.
        if (this.cameraStableSince <= this.pendingTask.getFrame()) {
            this.cullResults.put(CullType.LOCAL, result.getCullTreeLocal());
        }
        this.cullResults.put(CullType.REGULAR, result.getCullTreeRegular());
        this.cullResults.put(CullType.WIDE, result.getCullTreeWide());

        this.taskLists = result.getPendingTaskLists();

        this.invalidateRenderLists();
        this.pendingTask = null;

        // end the safe read phase on task completion
        this.renderSections.endSafeReadPhase();
    }

    private static Thread makeAsyncCullThread(Runnable runnable) {
        Thread thread = new Thread(runnable);
        thread.setName("Sodium Async Cull Thread");
        return thread;
    }

    private void scheduleAsyncWork(Viewport viewport, FogParameters fogParameters, boolean useOcclusionCulling) {
        if (this.pendingTask != null) {
            return;
        }

        // submit cull task if there's none running currently
        var searchDistanceRegular = this.getSearchDistanceForCullType(CullType.REGULAR, fogParameters);
        var searchDistanceLocal = this.getSearchDistanceForCullType(CullType.LOCAL, fogParameters);

        this.pendingTask = new CullTask(viewport, searchDistanceRegular, searchDistanceLocal, this.frame, this.occlusionCuller, useOcclusionCulling, this.level);
        this.renderSections.startSafeReadPhase();
        this.pendingTask.submitTo(this.asyncCullExecutor);

        // only clear the graph update if we actually scheduled a task. Otherwise, the currently running task might not pick up on the change and no additional task would have been scheduled.
        this.needsGraphUpdate = false;
    }

    private SectionTree findBestTree(Viewport viewport, FogParameters fogParameters) {
        for (var type : CullType.NARROW_TO_WIDE) {
            var tree = this.cullResults.get(type);
            if (tree == null) {
                continue;
            }

            float searchDistance = this.getSearchDistanceForCullType(type, fogParameters);
            if (tree.isValidFor(viewport, searchDistance)) {
                return tree;
            }
        }

        return null;
    }

    private void readRenderListFromTree(Viewport viewport, FogParameters fogParameters) {
        // pick the narrowest available tree
        var bestTree = this.findBestTree(viewport, fogParameters);

        // use out-of-graph fallback if the origin section is not loaded and there's no valid tree (missing origin section, empty world)
        if (bestTree == null && this.isOutOfGraph(viewport.getChunkCoord())) {
            this.renderOutOfGraph(viewport, fogParameters);
            return;
        }

        // wait for pending tasks to maybe supply a valid tree if there's no current tree (first frames after initial load/reload)
        if (bestTree == null) {
            this.consumeCullTaskResults(true);
            bestTree = this.findBestTree(viewport, fogParameters);
        }

        if (bestTree == null) {
            this.renderOutOfGraph(viewport, fogParameters);
            return;
        }

        var visibleCollector = new VisibleChunkCollector(this.regions, this.frame);
        bestTree.traverse(visibleCollector, viewport, this.getSearchDistance(fogParameters));
        this.renderLists = visibleCollector.createRenderLists(viewport);

        this.renderTree = bestTree;
    }

    private void renderOutOfGraph(Viewport viewport, FogParameters fogParameters) {
        var searchDistance = this.getSearchDistance(fogParameters);
        var visitor = new FallbackVisibleChunkCollector(viewport, searchDistance, this.frame, this.renderSections, this.regions, this.level);

        this.renderableSectionTree.prepareForTraversal();
        this.renderableSectionTree.traverse(visitor, viewport, searchDistance);

        this.renderLists = visitor.createRenderLists(viewport);
        this.taskLists = visitor.getPendingTaskLists();

        visitor.prepareForTraversal();
        this.renderTree = visitor;
    }

    private boolean isOutOfGraph(SectionPos pos) {
        var sectionY = pos.getY();
        return this.level.getMinSectionY() <= sectionY &&
                sectionY <= this.level.getMaxSectionY() &&
                !this.renderSections.hasSectionConsistent(pos.asLong());
    }

    public void markGraphDirty() {
        this.needsGraphUpdate = true;
    }

    public void notifyChangedCamera() {
        this.cameraChanged = true;
        this.cameraStableSince = this.frame;
    }

    public boolean needsUpdate() {
        return this.needsGraphUpdate;
    }

    private void invalidateRenderLists() {
        this.needsRenderListUpdate = true;
    }

    private float getSearchDistanceForCullType(CullType cullType, FogParameters fogParameters) {
        if (cullType.isFogCulled) {
            return this.getSearchDistance(fogParameters);
        } else {
            return this.getRenderDistance();
        }
    }

    private float getSearchDistance(FogParameters fogParameters) {
        float distance;

        if (SodiumClientMod.options().performance.useFogOcclusion) {
            distance = this.getEffectiveRenderDistance(fogParameters);
        } else {
            distance = this.getRenderDistance();
        }

        return distance;
    }

    public void beforeSectionUpdates() {
        this.renderableSectionTree.ensureCapacity(this.getRenderDistance());
    }

    public void onSectionAdded(int x, int y, int z) {
        long key = SectionPos.asLong(x, y, z);

        if (this.renderSections.hasSectionConsistent(key)) {
            return;
        }

        RenderRegion region = this.regions.createForChunk(x, y, z);

        RenderSection renderSection = new RenderSection(region, x, y, z);
        region.addSection(renderSection);

        this.renderSections.queuePut(key, renderSection);

        ChunkAccess chunk = this.level.getChunk(x, z);
        LevelChunkSection section = chunk.getSections()[this.level.getSectionIndexFromSectionY(y)];

        if (section.hasOnlyAir()) {
            this.updateSectionInfo(renderSection, BuiltSectionInfo.EMPTY);
        } else {
            this.renderableSectionTree.add(renderSection);
            renderSection.setPendingUpdate(ChunkUpdateTypes.INITIAL_BUILD, this.lastFrameAtTime);
        }

        this.connectNeighborNodes(renderSection);

        // force update to schedule build task
        this.markGraphDirty();
    }

    public void onSectionRemoved(int x, int y, int z) {
        long sectionPos = SectionPos.asLong(x, y, z);
        RenderSection section = this.renderSections.queueRemove(sectionPos);

        if (section == null) {
            return;
        }

        this.renderableSectionTree.remove(x, y, z);

        if (section.getTranslucentData() != null) {
            this.sortTriggering.removeSection(section.getTranslucentData(), sectionPos);
        }

        RenderRegion region = section.getRegion();

        if (region != null) {
            region.removeSection(section);
        }

        this.disconnectNeighborNodes(section);
        this.updateSectionInfo(section, null);

        section.delete();

        // force update to remove sections from render lists
        this.markGraphDirty();
    }

    public void tickVisibleRenders() {
        Iterator<ChunkRenderList> it = this.renderLists.iterator();

        while (it.hasNext()) {
            ChunkRenderList renderList = it.next();

            var region = renderList.getRegion();
            var iterator = renderList.sectionsWithSpritesIterator();

            if (iterator == null) {
                continue;
            }

            while (iterator.hasNext()) {
                var sprites = region.getAnimatedSprites(iterator.nextByteAsInt());

                if (sprites == null) {
                    continue;
                }

                for (TextureAtlasSprite sprite : sprites) {
                    SpriteUtil.INSTANCE.markSpriteActive(sprite);
                }
            }
        }
    }

    private boolean isSectionEmpty(int x, int y, int z) {
        RenderSection section = this.renderSections.getCurrent(x, y, z);

        if (section == null) {
            return true;
        }

        return section.isInvisible();
    }

    // renderTree is not necessarily frustum-filtered but that is ok since the caller makes sure to eventually also perform a frustum test on the box being tested (see EntityRendererMixin)
    public boolean isBoxVisible(double x1, double y1, double z1, double x2, double y2, double z2) {
        return this.renderTree == null || this.renderTree.isBoxVisible(x1, y1, z1, x2, y2, z2, this::isSectionEmpty);
    }

    public void processChunkBuilds(Viewport viewport, UniformBufferManager uniforms) {
        var results = this.collectChunkBuildResults();

        if (results.isEmpty()) {
            return;
        }

        // processing build results can cause invalidation of the render lists or change the connectivity of the graph. They don't necessarily imply each other, so they're tracked separately.
        int changes = this.processChunkBuildResults(results, viewport, uniforms);
        if ((changes & SectionInfoChange.GRAPH) != 0) {
            this.markGraphDirty();
        }
        if ((changes & SectionInfoChange.RENDER_LIST) != 0) {
            this.invalidateRenderLists();
        }

        for (var result : results) {
            result.destroy();
        }
    }

    private boolean isSectionImmediatePresentationCandidate(Viewport viewport, RenderSection section) {
        if (this.cameraPosition == null) {
            return false;
        }

        if (this.renderTree == null) {
            return true;
        }

        var distanceSquared = section.getSquaredDistance(
                (float) this.cameraPosition.x(),
                (float) this.cameraPosition.y(),
                (float) this.cameraPosition.z()
        );

        if (distanceSquared < NEARBY_REBUILD_DISTANCE) {
            return true;
        }
        if (distanceSquared >= IMMEDIATE_PRESENT_DISTANCE) {
            return false;
        }

        // unloaded sections are considered visible as to not be an impossible requirement for immediate presentation
        return (section.getAdjacentMask() != GraphDirectionSet.ALL ||
                this.renderTree.isSectionVisible(viewport, section) ||
                this.renderTree.isSectionVisible(viewport, section.adjacentDown) ||
                this.renderTree.isSectionVisible(viewport, section.adjacentUp) ||
                this.renderTree.isSectionVisible(viewport, section.adjacentNorth) ||
                this.renderTree.isSectionVisible(viewport, section.adjacentSouth) ||
                this.renderTree.isSectionVisible(viewport, section.adjacentWest) ||
                this.renderTree.isSectionVisible(viewport, section.adjacentEast));
    }

    private int processChunkBuildResults(ArrayList<BuilderTaskOutput> results, Viewport viewport, UniformBufferManager uniforms) {
        var sectionsWithOutputs = this.applyBuildOutputs(results);
        var outputs = new ArrayList<BuilderTaskOutput>();

        // prepare list of pending present patches if there are pending tasks that will need patches
        List<RenderSection> pendingPresentPatches = null;
        if (this.pendingTask != null) {
            pendingPresentPatches = new ReferenceArrayList<>();
        }

        int changes = SectionInfoChange.NONE;
        long totalUploadSize = 0;
        for (var section : sectionsWithOutputs) {
            var buildOutput = section.retrievePendingBuildOutput();
            if (buildOutput != null) {
                var resultSize = buildOutput.getResultSize();
                TranslucentData oldData = section.getTranslucentData();

                changes |= this.updateWithResult(viewport, section, buildOutput, pendingPresentPatches);

                section.setLastMeshResultSize(resultSize);
                this.meshTaskSizeEstimator.addData(this.meshTaskSizeEstimator.resultForSection(section, resultSize));

                if (buildOutput.translucentData != null) {
                    this.sortTriggering.integrateTranslucentData(oldData, buildOutput.translucentData, buildOutput.getSorter(), this.cameraPosition, this::scheduleSort);

                    // a rebuild always generates new translucent data which means applyTriggerChanges isn't necessary
                    section.setTranslucentData(buildOutput.translucentData);
                }

                outputs.add(buildOutput);
                totalUploadSize += resultSize;
            }

            var sortOutput = section.retrievePendingDynamicSortOutput(buildOutput);
            if (sortOutput != null) {
                var translucentData = section.getTranslucentData();
                if (translucentData instanceof DynamicData dynamicData &&
                        sortOutput.getSorter() instanceof DynamicSorter dynamicSorter &&
                        dynamicData.isMatchingSorter(dynamicSorter)) {
                    if (dynamicData instanceof DynamicTopoData data) {
                        var sorter = sortOutput.getSorter();
                        if (sorter instanceof DynamicTopoData.DynamicTopoSorter topoSorter) {
                            this.sortTriggering.applyTopoSortingTriggerChanges(data, topoSorter, section.getPosition(), this.cameraPosition);
                        }
                    }

                    outputs.add(sortOutput);
                    totalUploadSize += sortOutput.getResultSize();
                }
            }
        }

        this.meshTaskSizeEstimator.updateModels();

        if (pendingPresentPatches != null && !pendingPresentPatches.isEmpty() &&
                this.pendingTask != null) {
            this.pendingTask.registerPresentPatches(pendingPresentPatches);
        }

        var uploadStart = System.nanoTime();
        this.regions.uploadResults(outputs, uniforms);
        var uploadDuration = System.nanoTime() - uploadStart;

        // insert and update the upload duration estimator with the total upload size,
        // since we don't know which task took how long and the time it takes to upload is not independent between tasks
        // we take the average size and duration
        if (!outputs.isEmpty()) {
            var outputCount = outputs.size();
            this.jobUploadDurationEstimator.addData(new UploadDuration(uploadDuration / outputCount, totalUploadSize / outputCount));
            this.jobUploadDurationEstimator.updateModels();
        }

        return changes;
    }

    private int updateWithResult(Viewport viewport, RenderSection section, ChunkBuildOutput chunkBuildOutput, List<RenderSection> pendingPresentPatches) {
        var index = section.getSectionIndex();
        var prevFlags = section.getRegion().getSectionFlags(index);

        int changes = this.updateSectionInfo(section, chunkBuildOutput.info);

        // if result was blocking (or is approximately visible) and section is now newly renderable, force render it since it's probably a newly uncovered chunk.
        // This also fixes flickering issues with pistons moving blocks and switching between being a mesh and a BE.
        if (this.renderTree != null &&
                (chunkBuildOutput.blockingTask || this.isSectionImmediatePresentationCandidate(viewport, section)) &&
                RenderSectionFlags.renderingMoreTypesNow(prevFlags, chunkBuildOutput.info.flags)) {
            var chunkX = section.getChunkX();
            var chunkY = section.getChunkY();
            var chunkZ = section.getChunkZ();

            for (var tree : this.cullResults.values()) {
                if (tree.patchMarkPresent(chunkX, chunkY, chunkZ)) {
                    changes |= SectionInfoChange.RENDER_LIST;
                }
            }

            // collect present patches if we need to
            if (pendingPresentPatches != null) {
                pendingPresentPatches.add(section);
            }
        }

        return changes;
    }

    private int updateSectionInfo(RenderSection render, BuiltSectionInfo info) {
        if (info == null || RenderSectionFlags.isInvisible(info.flags)) {
            this.renderableSectionTree.remove(render);
        } else {
            this.renderableSectionTree.add(render);
        }

        int changes = render.setInfo(info);

        boolean globalSetChanged;
        if (info == null || ArrayUtils.isEmpty(info.globalBlockEntities)) {
            globalSetChanged = this.sectionsWithGlobalEntities.remove(render);
        } else {
            globalSetChanged = this.sectionsWithGlobalEntities.add(render);
        }

        // invalidate render list when membership of global block entity set changes
        if (globalSetChanged) {
            changes |= SectionInfoChange.RENDER_LIST;
        }

        return changes;
    }

    private List<RenderSection> applyBuildOutputs(ArrayList<BuilderTaskOutput> outputs) {
        var sectionsWithPendingOutputs = new ReferenceArrayList<RenderSection>();

        for (var output : outputs) {
            if (output.section.isDisposed()) {
                continue;
            }

            if (output.section.addBuildOutput(output)) {
                sectionsWithPendingOutputs.add(output.section);
            }
        }

        return sectionsWithPendingOutputs;
    }

    private ArrayList<BuilderTaskOutput> collectChunkBuildResults() {
        ArrayList<BuilderTaskOutput> results = new ArrayList<>();

        ChunkJobResult<? extends BuilderTaskOutput> result;

        while ((result = this.buildResults.poll()) != null) {
            results.add(result.unwrap());
            result.clearJobFromSection();

            var jobEffort = result.getJobEffort();
            if (jobEffort != null) {
                this.jobDurationEstimator.addData(jobEffort);
            }
        }

        this.jobDurationEstimator.updateModels();

        return results;
    }

    public void cleanupAndFlip(UniformBufferManager ubm) {
        this.sectionCache.cleanup();
        this.regions.update(ubm);
    }

    public void updateChunks(Viewport viewport, boolean updateImmediately) {
        this.thisFrameBlockingTasks = 0;
        this.nextFrameBlockingTasks = 0;
        this.deferredTasks = 0;

        var thisFrameBlockingCollector = this.lastBlockingCollector;
        this.lastBlockingCollector = null;
        if (thisFrameBlockingCollector == null) {
            thisFrameBlockingCollector = new ChunkJobCollector(this.buildResults::add);
        }

        if (updateImmediately) {
            // for a perfect frame where everything is finished use the last frame's blocking collector
            // and add all tasks to it so that they're waited on
            this.submitSectionTasks(thisFrameBlockingCollector, thisFrameBlockingCollector, thisFrameBlockingCollector, UnlimitedResourceBudget.INSTANCE, viewport);

            this.thisFrameBlockingTasks = thisFrameBlockingCollector.getSubmittedTaskCount();
            thisFrameBlockingCollector.awaitCompletion(this.builder);
        } else {
            var remainingDuration = this.builder.getTotalRemainingDuration(this.averageFrameDuration);

            // an estimator is used estimate task duration and limit the execution time to the available worker capacity.
            // separately, tasks are limited by their estimated upload size and duration.
            var uploadBudget = new LimitedResourceBudget(
                    Math.max((long) (this.averageFrameDuration * FRAME_DURATION_UPLOAD_FRACTION), MIN_UPLOAD_DURATION_BUDGET),
                    this.regions.getStagingBuffer().getUploadSizeLimit(this.averageFrameDuration));

            var nextFrameBlockingCollector = new ChunkJobCollector(this.buildResults::add);
            var deferredCollector = new ChunkJobCollector(remainingDuration, this.buildResults::add);

            this.submitSectionTasks(thisFrameBlockingCollector, nextFrameBlockingCollector, deferredCollector, uploadBudget, viewport);

            this.thisFrameBlockingTasks = thisFrameBlockingCollector.getSubmittedTaskCount();
            this.nextFrameBlockingTasks = nextFrameBlockingCollector.getSubmittedTaskCount();
            this.deferredTasks = deferredCollector.getSubmittedTaskCount();

            // wait on this frame's blocking collector which contains the important tasks from this frame
            // and semi-important tasks from the last frame
            thisFrameBlockingCollector.awaitCompletion(this.builder);

            // store the semi-important collector to wait on it in the next frame
            this.lastBlockingCollector = nextFrameBlockingCollector;
        }
    }

    private void submitSectionTasks(
            ChunkJobCollector importantCollector, ChunkJobCollector semiImportantCollector, ChunkJobCollector deferredCollector, UploadResourceBudget uploadBudget, Viewport viewport) {
        this.submitImportantSectionTasks(importantCollector, uploadBudget, DeferMode.ZERO_FRAMES, viewport);
        this.submitImportantSectionTasks(semiImportantCollector, uploadBudget, DeferMode.ONE_FRAME, viewport);
        this.submitImportantSectionTasks(deferredCollector, uploadBudget, DeferMode.ALWAYS, viewport);

        this.submitDeferredSectionTasks(deferredCollector, uploadBudget);
    }

    private void submitDeferredSectionTasks(ChunkJobCollector collector, UploadResourceBudget uploadBudget) {
        if (this.taskLists == null) {
            return;
        }

        while (!this.taskLists.isEmpty() && collector.hasBudgetRemaining() && uploadBudget.isAvailable()) {
            var section = this.renderSections.getConsistent(this.taskLists.dequeueNextSectionPos());
            if (section != null) {
                this.submitSectionTask(collector, section, uploadBudget);
            }
        }
    }

    private DeferMode getDeferModeForPendingUpdate(int type) {
        return ChunkUpdateTypes.getDeferMode(type, SodiumClientMod.options().performance.chunkBuildDeferMode, this.sortBehavior.getDeferMode());
    }

    private void submitImportantSectionTasks(ChunkJobCollector collector, UploadResourceBudget uploadBudget, DeferMode deferMode, Viewport viewport) {
        var it = this.importantTasks.get(deferMode).iterator();

        while (it.hasNext() && collector.hasBudgetRemaining() && (deferMode.allowsUnlimitedUploadDuration() || uploadBudget.isAvailable())) {
            var section = it.next();
            var pendingUpdate = section.getPendingUpdate();

            if (pendingUpdate != 0 && this.getDeferModeForPendingUpdate(pendingUpdate) == deferMode && this.shouldPrioritizeTask(section, NEARBY_SORT_DISTANCE)) {
                // isSectionVisible includes a special case for not testing empty sections against the tree as they won't be in it
                if (this.renderTree == null || this.renderTree.isSectionVisible(viewport, section)) {
                    this.submitSectionTask(collector, section, pendingUpdate, uploadBudget, deferMode == DeferMode.ZERO_FRAMES);
                } else {
                    // don't remove if simply not visible currently but still relevant
                    continue;
                }
            }
            it.remove();
        }
    }

    private void submitSectionTask(ChunkJobCollector collector, @NotNull RenderSection section, UploadResourceBudget uploadBudget) {
        // don't schedule tasks for sections that don't need it anymore,
        // since the pending update it cleared when a task is started, this includes
        // sections for which there's a currently running task.
        var type = section.getPendingUpdate();
        if (type == 0) {
            return;
        }

        this.submitSectionTask(collector, section, type, uploadBudget, false);
    }

    private void submitSectionTask(ChunkJobCollector collector, @NonNull RenderSection section, int type, UploadResourceBudget uploadBudget, boolean blocking) {
        if (section.isDisposed()) {
            return;
        }

        ChunkBuilderTask<? extends BuilderTaskOutput> task;
        if (ChunkUpdateTypes.isInitialBuild(type) || ChunkUpdateTypes.isRebuild(type)) {
            task = this.createRebuildTask(section, this.frame, blocking);

            if (task == null) {
                // if the section is empty or doesn't exist submit this null-task to set the
                // built flag on the render section.
                // It's important to use a NoData instead of null translucency data here in
                // order for it to clear the old data from the translucency sorting system.
                // This doesn't apply to sorting tasks as that would result in the section being
                // marked as empty just because it was scheduled to be sorted and its dynamic
                // data has since been removed. In that case simply nothing is done as the
                // rebuild that must have happened in the meantime includes new non-dynamic
                // index data.
                TranslucentData translucentData = null;
                if (this.sortBehavior != SortBehavior.OFF) {
                    translucentData = NoData.forEmptySection(section.getPosition());
                }
                var result = ChunkJobResult.successfully(new ChunkBuildOutput(
                        section, this.frame, translucentData,
                        BuiltSectionInfo.EMPTY, Collections.emptyMap(), false));
                this.buildResults.add(result);
            }
        } else { // implies it's a type of sort task
            task = this.createSortTask(section, this.frame);

            if (task == null) {
                // when a sort task is null it means the render section has no dynamic data and
                // doesn't need to be sorted. Nothing needs to be done.
                section.clearPendingUpdate();
                return;
            }
        }

        if (task != null) {
            var job = this.builder.scheduleTask(task, ChunkUpdateTypes.isImportant(type), collector::onJobFinished);
            collector.addSubmittedJob(job);

            // consume upload budget in size and duration using estimates
            uploadBudget.consume(task.getEstimatedUploadDuration(), task.getEstimatedSize());

            section.addRunningJob(job);
        }

        section.clearPendingUpdate();
    }

    public @Nullable ChunkBuilderMeshingTask createRebuildTask(RenderSection render, int frame, boolean blocking) {
        ChunkRenderContext context = LevelSlice.prepare(this.level, render.getPosition(), this.sectionCache);

        if (context == null) {
            return null;
        }

        var task = new ChunkBuilderMeshingTask(render, frame, this.cameraPosition, context, this.sortBehavior, ChunkUpdateTypes.isRebuildWithSort(render.getPendingUpdate()), blocking);
        task.calculateEstimations(this.jobDurationEstimator, this.meshTaskSizeEstimator, this.jobUploadDurationEstimator);
        return task;
    }

    public ChunkBuilderSortingTask createSortTask(RenderSection render, int frame) {
        var task = ChunkBuilderSortingTask.createTask(render, frame, this.cameraPosition);
        if (task != null) {
            task.calculateEstimations(this.jobDurationEstimator, this.meshTaskSizeEstimator, this.jobUploadDurationEstimator);
        }
        return task;
    }

    public void processGFNIMovement(CameraMovement movement) {
        if (this.sortTriggering != null) {
            this.sortTriggering.triggerSections(this::scheduleSort, movement);
        }
    }

    public ChunkBuilder getBuilder() {
        return this.builder;
    }

    public void destroy() {
        // stop all the workers and cancel any tasks
        this.builder.shutdown();

        // shutdown async task executor and wait for it to terminate
        this.asyncCullExecutor.shutdownNow();
        try {
            if (!this.asyncCullExecutor.awaitTermination(10, TimeUnit.SECONDS)) {
                throw new RuntimeException("Shutting down async culling task executor timed out");
            }
        } catch (InterruptedException e) {
            throw new RuntimeException("Interrupted while waiting for async culling task executor to shutdown", e);
        }

        for (var result : this.collectChunkBuildResults()) {
            result.destroy(); // delete resources for any pending tasks (including those that were cancelled)
        }

        this.renderSections.deleteAll();

        this.sectionsWithGlobalEntities.clear();

        this.renderLists = SortedRenderLists.empty();

        this.regions.delete();
        this.chunkRenderer.delete();
    }

    public int getTotalSections() {
        return this.renderSections.size();
    }

    public int getVisibleChunkCount() {
        var sections = 0;
        var iterator = this.renderLists.iterator();

        while (iterator.hasNext()) {
            var renderList = iterator.next();
            sections += renderList.getSectionsWithGeometryCount();
        }

        return sections;
    }

    private boolean upgradePendingUpdate(RenderSection section, int updateType) {
        if (updateType == 0) {
            return false;
        }

        var current = section.getPendingUpdate();
        var joined = ChunkUpdateTypes.join(current, updateType);

        if (joined == current) {
            return false;
        }

        section.setPendingUpdate(joined, this.lastFrameAtTime);

        // when the pending task type changes, and it's important, add it to the list of important tasks
        if (ChunkUpdateTypes.isImportant(joined)) {
            this.importantTasks.get(this.getDeferModeForPendingUpdate(joined)).add(section);
        }

        this.markGraphDirty();

        return true;
    }

    public void scheduleSort(long sectionPos, boolean isDirectTrigger) {
        RenderSection section = this.renderSections.getConsistent(sectionPos);

        if (section != null) {
            int pendingUpdate = ChunkUpdateTypes.SORT;
            var priorityMode = this.sortBehavior.getPriorityMode();
            if (priorityMode == PriorityMode.NEARBY && this.shouldPrioritizeTask(section, NEARBY_SORT_DISTANCE) || priorityMode == PriorityMode.ALL) {
                pendingUpdate = ChunkUpdateTypes.join(pendingUpdate, ChunkUpdateTypes.IMPORTANT);
            }

            if (this.upgradePendingUpdate(section, pendingUpdate)) {
                section.prepareTrigger(isDirectTrigger);
            }
        }
    }

    public void scheduleRebuild(int x, int y, int z, boolean playerChanged) {
        RenderAsserts.validateCurrentThread();

        var key = SectionPos.asLong(x, y, z);
        this.sectionCache.invalidate(key);

        RenderSection section = this.renderSections.getConsistent(key);

        if (section != null && section.isBuilt()) {
            int pendingUpdate;

            if (playerChanged && this.shouldPrioritizeTask(section, NEARBY_REBUILD_DISTANCE)) {
                pendingUpdate = ChunkUpdateTypes.join(ChunkUpdateTypes.REBUILD, ChunkUpdateTypes.IMPORTANT);
            } else {
                pendingUpdate = ChunkUpdateTypes.REBUILD;
            }

            this.upgradePendingUpdate(section, pendingUpdate);
        }
    }

    private boolean shouldPrioritizeTask(RenderSection section, float distance) {
        return this.cameraPosition != null && section.getSquaredDistance(
                (float) this.cameraPosition.x(),
                (float) this.cameraPosition.y(),
                (float) this.cameraPosition.z()
        ) < distance;
    }

    private float getEffectiveRenderDistance(FogParameters fogParameters) {
        var alpha = fogParameters.alpha();

        var renderDistance = this.getRenderDistance();

        // The fog must be fully opaque in order to skip rendering of chunks behind it
        if (!Mth.equal(alpha, 1.0f)) {
            return renderDistance;
        }

        return Math.min(renderDistance, fogParameters.cullDistance() + 0.5f);
    }

    private float getRenderDistance() {
        return this.renderDistance * 16.0f;
    }

    private void connectNeighborNodes(RenderSection render) {
        for (int direction = 0; direction < GraphDirection.COUNT; direction++) {
            RenderSection adj = this.getRenderSection(render.getChunkX() + GraphDirection.x(direction),
                    render.getChunkY() + GraphDirection.y(direction),
                    render.getChunkZ() + GraphDirection.z(direction));

            if (adj != null) {
                adj.setAdjacentNode(GraphDirection.opposite(direction), render);
                render.setAdjacentNode(direction, adj);
            }
        }
    }

    private void disconnectNeighborNodes(RenderSection render) {
        for (int direction = 0; direction < GraphDirection.COUNT; direction++) {
            RenderSection adj = render.getAdjacent(direction);

            if (adj != null) {
                adj.setAdjacentNode(GraphDirection.opposite(direction), null);
                render.setAdjacentNode(direction, null);
            }
        }
    }

    private RenderSection getRenderSection(int x, int y, int z) {
        return this.renderSections.getConsistent(SectionPos.asLong(x, y, z));
    }

    public Collection<String> getDebugStrings(boolean verbose) {
        List<String> list = new ArrayList<>();

        int count = 0;

        long geometryDeviceUsed = 0;
        long geometryDeviceAllocated = 0;
        long indexDeviceUsed = 0;
        long indexDeviceAllocated = 0;

        for (var region : this.regions.getLoadedRegions()) {
            var resources = region.getResources();

            if (resources == null) {
                continue;
            }

            var geometryArena = resources.getGeometryAllocator();
            if (geometryArena.isSingleOwner()) {
                geometryDeviceUsed += geometryArena.getDeviceUsedMemory();
                geometryDeviceAllocated += geometryArena.getDeviceAllocatedMemory();
                count++;
            }

            var indexArena = resources.getIndexAllocator();
            if (indexArena.isSingleOwner()) {
                indexDeviceUsed += indexArena.getDeviceUsedMemory();
                indexDeviceAllocated += indexArena.getDeviceAllocatedMemory();
                count++;
            }
        }

        var aggregator = this.regions.getArenaAggregator();
        geometryDeviceUsed += aggregator.getGeometryDeviceUsedMemory();
        geometryDeviceAllocated += aggregator.getGeometryDeviceAllocatedMemory();
        indexDeviceUsed += aggregator.getIndexDeviceUsedMemory();
        indexDeviceAllocated += aggregator.getIndexDeviceAllocatedMemory();
        count += aggregator.getBufferCount();

        if (verbose) {
            list.add(String.format("Pools: Geometry %d/%d MiB, Index %d/%d MiB, Misc %d MiB, %d buffers",
                    MathUtil.toMib(geometryDeviceUsed), MathUtil.toMib(geometryDeviceAllocated),
                    MathUtil.toMib(indexDeviceUsed), MathUtil.toMib(indexDeviceAllocated),
                    aggregator.getMiscAllocatedMemory(), count));
            list.add(String.format("Transfer Queue: %s", this.regions.getStagingBuffer().toString()));
        } else {
            list.add(String.format("G:%d/%d I:%d/%d MiB TQ: %s #%d",
                    MathUtil.toMib(geometryDeviceUsed), MathUtil.toMib(geometryDeviceAllocated),
                    MathUtil.toMib(indexDeviceUsed), MathUtil.toMib(indexDeviceAllocated),
                    this.regions.getStagingBuffer().toString(), count));
        }

        if (verbose) {
            list.add(String.format("Chunk Builder: Schd=%02d | Busy=%02d (%04d%%) | Total=%02d",
                    this.builder.getScheduledJobCount(), this.builder.getBusyThreadCount(), (int) (this.builder.getBusyFraction(this.lastFrameDuration) * 100), this.builder.getTotalThreadCount())
            );
        } else {
            list.add(String.format("B: S%02d/B%02d/T%02d",
                    this.builder.getScheduledJobCount(), this.builder.getBusyThreadCount(), this.builder.getTotalThreadCount())
            );
        }

        if (verbose) {
            list.add(String.format("Tasks: N0=%03d | N1=%03d | Def=%03d, Recv=%03d",
                    this.thisFrameBlockingTasks, this.nextFrameBlockingTasks, this.deferredTasks, this.buildResults.size())
            );
        }

        if (verbose && PlatformRuntimeInformation.getInstance().isDevelopmentEnvironment()) {
            var meshTaskParameters = this.jobDurationEstimator.toString(ChunkBuilderMeshingTask.class);
            var sortTaskParameters = this.jobDurationEstimator.toString(ChunkBuilderSortingTask.class);
            var uploadDurationParameters = this.jobUploadDurationEstimator.toString(null);
            list.add(String.format("Duration: Mesh %s, Sort %s, Upload %s", meshTaskParameters, sortTaskParameters, uploadDurationParameters));

            var sizeEstimates = new ReferenceArrayList<String>();
            for (var type : MeshResultSize.SectionCategory.values()) {
                sizeEstimates.add(String.format("%s=%s", type, this.meshTaskSizeEstimator.toString(type)));
            }
            list.add(String.format("Size: %s", String.join(", ", sizeEstimates)));
        }

        if (this.sortBehavior != SortBehavior.OFF) {
            this.sortTriggering.addDebugStrings(list, this.sortBehavior, verbose);
        } else {
            list.add("TS OFF");
        }

        var cullState = this.pendingTask == null ? "Idle" : this.pendingTask.isDone() ? "Done" : "Running";
        var cullDuration = this.averageCullDurationNanos == -1 ? "?" : String.format("%.1fms", this.averageCullDurationNanos / 1_000_000.0);
        if (verbose) {
            list.add(String.format("%s AC: %s (avg %s)", this.renderSections.getDebugInfo(), cullState, cullDuration));
        } else {
            list.add(String.format("Async Culling: %s (avg %s)", cullState, cullDuration));
        }

        return list;
    }

    public String getChunksDebugString() {
        // C: visible/total D: distance
        return String.format(
                "C: %d/%d (%s) D: %d",
                this.getVisibleChunkCount(),
                this.getTotalSections(),
                this.getCullTypeName(),
                this.renderDistance);
    }

    private String getCullTypeName() {
        CullType renderTreeCullType = null;
        for (var type : CullType.values()) {
            if (this.cullResults.get(type) == this.renderTree) {
                renderTreeCullType = type;
                break;
            }
        }
        var cullTypeName = "-";
        if (renderTreeCullType != null) {
            cullTypeName = renderTreeCullType.abbreviation;
        }
        return cullTypeName;
    }

    public @NonNull SortedRenderLists getRenderLists() {
        return this.renderLists;
    }

    public ChunkRenderer getChunkRenderer() {
        return this.chunkRenderer;
    }

    public int getFrame() {
        return this.frame;
    }

    public boolean isSectionBuilt(int x, int y, int z) {
        var section = this.getRenderSection(x, y, z);
        return section != null && section.isBuilt();
    }

    public void onChunkAdded(int x, int z) {
        for (int y = this.level.getMinSectionY(); y <= this.level.getMaxSectionY(); y++) {
            this.onSectionAdded(x, y, z);
        }
    }

    public void onChunkRemoved(int x, int z) {
        for (int y = this.level.getMinSectionY(); y <= this.level.getMaxSectionY(); y++) {
            this.onSectionRemoved(x, y, z);
        }
    }

    public Collection<RenderSection> getSectionsWithGlobalEntities() {
        return ReferenceSets.unmodifiable(this.sectionsWithGlobalEntities);
    }

    public void renderBufferDebug(GuiGraphicsExtractor guiGraphics) {
        this.regions.getArenaAggregator().renderBufferDebug(guiGraphics);
    }
}
