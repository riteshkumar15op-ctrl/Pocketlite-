package net.caffeinemc.mods.sodium.client.render.chunk.translucent_sorting.data;

import it.unimi.dsi.fastutil.objects.Object2ReferenceMap;
import net.caffeinemc.mods.sodium.client.render.chunk.translucent_sorting.quad.TQuad;
import net.caffeinemc.mods.sodium.client.render.chunk.translucent_sorting.trigger.GeometryPlanes;
import net.caffeinemc.mods.sodium.client.util.sorting.RadixSort;
import net.minecraft.core.SectionPos;
import org.joml.Vector3dc;
import org.joml.Vector3fc;

import java.nio.IntBuffer;
import java.util.function.IntConsumer;
import java.util.function.Supplier;

/**
 * Performs dynamic topo sorting and falls back to distance sorting as
 * necessary. This class implements a number of heuristics to attempt to upgrade
 * distance-based sorting back to topo sorting when possible as topo sorting
 * generally needs to happen far less often.
 * <p>
 * Triggering is performed when the quads' planes crossed along their normal
 * direction (unidirectional).
 * <p>
 * Implementation note:
 * - Reusing the output of previous distance sorting job doesn't make a
 * difference or makes things slower in some cases. It's unclear why exactly
 * this happens, I suspect weird memory behavior or the reuse is not actually
 * that helpful to the sorting algorithm.
 */
public class DynamicTopoData extends DynamicData {
    private static final int MAX_TOPO_SORT_QUADS = 1000;
    private static final int MAX_TOPO_SORT_TIME_NS = 1_000_000;
    private static final int MAX_FAILING_TOPO_SORT_TIME_NS = 750_000;
    private static final int MAX_TOPO_SORT_PATIENT_TIME_NS = 250_000;
    private static final int PATIENT_TOPO_ATTEMPTS = 5;
    private static final int REGULAR_TOPO_ATTEMPTS = 2;

    private boolean GFNITrigger;
    private boolean directTrigger;
    private int consecutiveTopoSortFailures = 0;

    private double directTriggerKey = -1;
    private boolean pendingTriggerIsDirect;

    private TQuad[] quads;
    private Vector3fc[] centroids;
    private Object2ReferenceMap<Vector3fc, float[]> distancesByNormal;

    private DynamicTopoData(SectionPos sectionPos, TQuad[] quads,
                            GeometryPlanes geometryPlanes, Vector3dc initialCameraPos,
                            Supplier<Object2ReferenceMap<Vector3fc, float[]>> distancesByNormal) {
        super(sectionPos, quads.length, geometryPlanes, initialCameraPos);

        if (this.getInputQuadCount() > MAX_TOPO_SORT_QUADS) {
            this.directTrigger = true;
            this.GFNITrigger = false;

            this.computeCentroids(quads);
        } else {
            this.directTrigger = false;
            this.GFNITrigger = true;

            this.quads = quads;
            this.distancesByNormal = distancesByNormal.get();
        }
    }

    private void computeCentroids(TQuad[] quads) {
        this.centroids = new Vector3fc[quads.length];
        for (int i = 0; i < quads.length; i++) {
            this.centroids[i] = quads[i].getCenter();
        }
    }

    @Override
    public DynamicSorter getSorter(boolean initial) {
        return new DynamicTopoSorter(this.getInputQuadCount(), this.pendingTriggerIsDirect, initial, this.consecutiveTopoSortFailures, this.GFNITrigger, this.directTrigger, this.quads, this.centroids, this.distancesByNormal);
    }

    public boolean GFNITriggerEnabled() {
        return this.GFNITrigger;
    }

    public boolean directTriggerEnabled() {
        return this.directTrigger;
    }

    public double getDirectTriggerKey() {
        return this.directTriggerKey;
    }

    public void setDirectTriggerKey(double key) {
        this.directTriggerKey = key;
    }

    public boolean checkAndApplyGFNITriggerOff(DynamicTopoSorter sorter) {
        if (this.GFNITrigger && !sorter.GFNITrigger) {
            this.GFNITrigger = false;

            // once the GFNI trigger is turned off, the topo sort data is never used again, so it can be freed to save memory.
            this.computeCentroids(this.quads);
            this.quads = null;
            this.distancesByNormal = null;

            return true;
        }
        return false;
    }

    public boolean checkAndApplyDirectTriggerOff(DynamicTopoSorter sorter) {
        if (this.directTrigger && !sorter.directTrigger) {
            this.directTrigger = false;
            return true;
        }
        return false;
    }

    public boolean checkAndApplyDirectTriggerOn(DynamicTopoSorter sorter) {
        if (!this.directTrigger && sorter.directTrigger) {
            this.directTrigger = true;
            return true;
        }
        return false;
    }

    public void applyTopoSortFailureCounterChange(DynamicTopoSorter sorter) {
        if (sorter.hasSortFailureReset()) {
            this.consecutiveTopoSortFailures = 0;
        } else if (sorter.hasSortFailureIncrement()) {
            this.consecutiveTopoSortFailures++;
        }
    }

    @Override
    public void prepareTrigger(boolean isDirectTrigger) {
        this.pendingTriggerIsDirect = isDirectTrigger;
    }

    public class DynamicTopoSorter extends DynamicSorter implements IntConsumer {
        private final boolean isDirectTrigger;
        private final boolean initial;
        private final int consecutiveTopoSortFailures;

        private boolean directTrigger;
        private boolean GFNITrigger;
        private int consecutiveTopoSortFailuresNew;

        private IntBuffer intBuffer;

        private final TQuad[] quads;
        private final Vector3fc[] centroids;
        private final Object2ReferenceMap<Vector3fc, float[]> distancesByNormal;

        private DynamicTopoSorter(int quadCount, boolean isDirectTrigger, boolean initial, int consecutiveTopoSortFailures, boolean GFNITrigger, boolean directTrigger, TQuad[] quads, Vector3fc[] centroids, Object2ReferenceMap<Vector3fc, float[]> distancesByNormal) {
            super(quadCount, DynamicTopoData.this, DynamicTopoData.this.geometryPlanes);
            this.isDirectTrigger = isDirectTrigger;
            this.initial = initial;
            this.consecutiveTopoSortFailures = consecutiveTopoSortFailures;
            this.consecutiveTopoSortFailuresNew = consecutiveTopoSortFailures;
            this.GFNITrigger = GFNITrigger;
            this.directTrigger = directTrigger;

            this.quads = quads;
            this.centroids = centroids;
            this.distancesByNormal = distancesByNormal;
        }

        private static int getAttemptsForTime(long ns) {
            return ns <= MAX_TOPO_SORT_PATIENT_TIME_NS ? PATIENT_TOPO_ATTEMPTS : REGULAR_TOPO_ATTEMPTS;
        }

        private boolean hasSortFailureReset() {
            return this.consecutiveTopoSortFailuresNew < this.consecutiveTopoSortFailures;
        }

        private boolean hasSortFailureIncrement() {
            return this.consecutiveTopoSortFailuresNew > this.consecutiveTopoSortFailures;
        }

        @Override
        public void accept(int value) {
            TranslucentData.writeQuadVertexIndexes(this.intBuffer, value);
        }

        @Override
        void writeSort(CombinedCameraPos cameraPos) {
            // uses a topo sort or a distance sort depending on what is enabled
            IntBuffer indexBuffer = this.getIntBuffer();

            if (this.GFNITrigger && !this.isDirectTrigger) {
                this.intBuffer = indexBuffer;
                var sortStart = this.initial ? 0 : System.nanoTime();
                var result = TopoGraphSorting.topoGraphSort(this, this.quads, this.distancesByNormal, cameraPos.getRelativeCameraPos(), false);
                this.intBuffer = null;

                var sortTime = this.initial ? 0 : System.nanoTime() - sortStart;

                // if we've already failed, there's reduced patience for sorting since the
                // probability of failure and wasted compute time is higher. Initial sorting is
                // often very slow when the cpu is loaded, and the JIT isn't ready yet, so it's
                // ignored here.
                if (!this.initial && sortTime > (this.consecutiveTopoSortFailuresNew > 0
                        ? MAX_FAILING_TOPO_SORT_TIME_NS
                        : MAX_TOPO_SORT_TIME_NS)) {
                    this.directTrigger = true;
                    this.GFNITrigger = false;
                } else if (result) {
                    // disable distance sorting because topo sort seems to be possible.
                    this.directTrigger = false;
                    this.consecutiveTopoSortFailuresNew = 0;
                } else {
                    // topo sort failure, the topo sort algorithm doesn't work on all cases

                    // gives up after a certain number of failures. it keeps GFNI triggering with
                    // topo sort on while the angle triggering is also active to maybe get a topo
                    // sort success from a different angle.
                    this.consecutiveTopoSortFailuresNew++;
                    this.directTrigger = true;
                    if (this.consecutiveTopoSortFailuresNew >= getAttemptsForTime(sortTime)) {
                        this.GFNITrigger = false;
                    }
                }
            }

            if (this.directTrigger) {
                indexBuffer.rewind();
                distanceSortDirect(indexBuffer, this.centroids, this.quads, cameraPos.getRelativeCameraPos());
            }
        }
    }

    /**
     * Sorts the given quads by descending center distance to the camera and writes
     * the resulting order to the given index buffer.
     */
    static void distanceSortDirect(IntBuffer indexBuffer, Vector3fc[] centroids, TQuad[] quads, Vector3fc cameraPos) {
        int count;
        if (centroids != null) {
            count = centroids.length;
        } else {
            count = quads.length;
        }

        if (count <= 1) {
            // Avoid allocations when there is nothing to sort.
            TranslucentData.writeQuadVertexIndexes(indexBuffer, 0);
        } else {
            final var keys = new int[count];
            final var perm = new int[count];

            for (int idx = 0; idx < count; idx++) {
                Vector3fc centroid;
                if (centroids != null) {
                    centroid = centroids[idx];
                } else {
                    centroid = quads[idx].getCenter();
                }
                keys[idx] = ~Float.floatToRawIntBits(centroid.distanceSquared(cameraPos));
                perm[idx] = idx;
            }

            RadixSort.sortIndirect(perm, keys, false);

            for (int idx = 0; idx < count; idx++) {
                TranslucentData.writeQuadVertexIndexes(indexBuffer, perm[idx]);
            }
        }
    }

    public static DynamicTopoData fromMesh(CombinedCameraPos cameraPos, TQuad[] quads, SectionPos sectionPos, GeometryPlanes geometryPlanes) {
        return new DynamicTopoData(sectionPos, quads, geometryPlanes, cameraPos.getAbsoluteCameraPos(), geometryPlanes::prepareAndGetDistances);
    }
}
